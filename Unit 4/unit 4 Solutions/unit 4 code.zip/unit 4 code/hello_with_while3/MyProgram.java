import java.util.Scanner;

/**
 * Write a description of class MyProgram here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyProgram
{
    public void runMyProgram()
    {
        Scanner reader = new Scanner(System.in);
        //Write your code here
        //Can you change this so target depends on user input?
        int count = 0; 
        System.out.println("How many times?");
        int target = reader.nextInt();

        while (count < target)
        {
            System.out.println((count+1) + "Hello World!");
            count = count + 1;
        }
    }
    
    public static void main(String[] args)
    { 
        MyProgram prog = new MyProgram();
        prog.runMyProgram();
    }
}
